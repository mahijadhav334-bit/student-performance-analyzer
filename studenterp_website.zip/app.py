from flask import Flask, render_template, request, redirect, url_for, send_file
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.hybrid import hybrid_property
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import pandas as pd
import io

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///student.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


# ==========================
# STUDENT MODEL
# ==========================
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(100))
    usn = db.Column(db.String(20))
    department = db.Column(db.String(50))
    attendance = db.Column(db.Float)

    python = db.Column(db.Float)
    dbms = db.Column(db.Float)
    dsa = db.Column(db.Float)
    maths = db.Column(db.Float)
    fcn = db.Column(db.Float)

    def average_marks(self):
        return (
            self.python +
            self.dbms +
            self.dsa +
            self.maths +
            self.fcn
        ) / 5

    @hybrid_property
    def marks(self):
        return self.average_marks()

    @marks.expression
    def marks(cls):
        return (
            cls.python +
            cls.dbms +
            cls.dsa +
            cls.maths +
            cls.fcn
        ) / 5

    def result(self):
        avg = self.average_marks()

        if avg >= 85:
            return "Distinction"
        elif avg >= 60:
            return "First Class"
        elif avg >= 40:
            return "Pass"
        else:
            return "Fail"


with app.app_context():
    db.create_all()


# ==========================
# HOME
# ==========================
@app.route('/')
def home():
    return render_template('index.html')


# ==========================
# STUDENT LOGIN
# ==========================
@app.route('/student', methods=['GET', 'POST'])
def student():

    if request.method == 'POST':

        usn = request.form['usn']

        student = Student.query.filter_by(usn=usn).first()

        if student:
            return redirect(url_for('student_dashboard', id=student.id))

        return "Invalid USN"

    return render_template('student_login.html')


# ==========================
# TEACHER LOGIN
# ==========================
@app.route('/teacher', methods=['GET', 'POST'])
def teacher_login():

    if request.method == 'POST':

        teacher_id = request.form['teacher_id']
        password = request.form['password']

        if teacher_id == "admin" and password == "admin123":
            return redirect(url_for('instructor'))

        return render_template(
            'teacher_login.html',
            error="Invalid Teacher ID or Password"
        )

    return render_template('teacher_login.html')


# ==========================
# INSTRUCTOR PAGE
@app.route('/instructor')
def instructor():

    students = Student.query.all()
    total_students = len(students)
    avg_marks = round(sum(s.marks for s in students) / total_students, 2) if total_students else 0
    avg_attendance = round(sum(s.attendance for s in students) / total_students, 2) if total_students else 0
    pass_rate = round(sum(1 for s in students if s.marks >= 40) / total_students * 100, 2) if total_students else 0

    # Subject-wise averages
    subject_avg = {}
    subjects = {'python': 'Python', 'dbms': 'DBMS', 'dsa': 'DSA', 'maths': 'Maths', 'fcn': 'FCN'}
    for key, label in subjects.items():
        values = [getattr(s, key) for s in students]
        subject_avg[label] = round(sum(values) / len(values), 2) if values else 0

    # Performance distribution (count by grade)
    grade_dist = {
        'Distinction': sum(1 for s in students if s.marks >= 85),
        'First Class': sum(1 for s in students if 60 <= s.marks < 85),
        'Pass': sum(1 for s in students if 40 <= s.marks < 60),
        'Fail': sum(1 for s in students if s.marks < 40)
    }

    return render_template(
        'instructor.html',
        total_students=total_students,
        avg_marks=avg_marks,
        avg_attendance=avg_attendance,
        pass_rate=pass_rate,
        subject_avg=subject_avg,
        grade_dist=grade_dist
    )


# ==========================
# STUDENT DASHBOARD
# ==========================
@app.route('/student_dashboard/<int:id>')
def student_dashboard(id):

    student = Student.query.get_or_404(id)

    return render_template(
        'student_dashboard.html',
        student=student
    )


# ==========================
# TEACHER DASHBOARD
# ==========================
@app.route('/teacher_dashboard')
def teacher_dashboard():

    search = request.args.get('search', '')

    if search:
        students = Student.query.filter(
            (Student.name.contains(search)) |
            (Student.usn.contains(search))
        ).all()
    else:
        students = Student.query.all()

    total_students = len(students)
    avg_marks = round(sum(s.marks for s in students) / total_students, 2) if total_students else 0
    avg_attendance = round(sum(s.attendance for s in students) / total_students, 2) if total_students else 0
    pass_rate = round(sum(1 for s in students if s.marks >= 40) / total_students * 100, 2) if total_students else 0

    subject_stats = {}
    for key, label in [
        ('python', 'Python'),
        ('dbms', 'DBMS'),
        ('dsa', 'DSA'),
        ('maths', 'Maths'),
        ('fcn', 'FCN')
    ]:
        values = [getattr(s, key) for s in students]
        subject_stats[label] = {
            'avg': round(sum(values) / len(values), 2) if values else 0,
            'max': round(max(values), 2) if values else 0,
            'min': round(min(values), 2) if values else 0
        }

    return render_template(
        'teacher_dashboard.html',
        students=students,
        total_students=total_students,
        avg_marks=avg_marks,
        avg_attendance=avg_attendance,
        pass_rate=pass_rate,
        subject_stats=subject_stats
    )


# ==========================
# ADD STUDENT
# ==========================
@app.route('/add_student', methods=['GET', 'POST'])
def add_student():

    if request.method == 'POST':

        student = Student(
            name=request.form['name'],
            usn=request.form['usn'],
            department=request.form['department'],
            attendance=float(request.form['attendance']),
            python=float(request.form['python']),
            dbms=float(request.form['dbms']),
            dsa=float(request.form['dsa']),
            maths=float(request.form['maths']),
            fcn=float(request.form['fcn'])
        )

        db.session.add(student)
        db.session.commit()

        return redirect(url_for('teacher_dashboard'))

    return render_template('add_student.html')


# ==========================
# EDIT STUDENT
# ==========================
@app.route('/edit_student/<int:id>', methods=['GET', 'POST'])
def edit_student(id):

    student = Student.query.get_or_404(id)

    if request.method == 'POST':

        student.name = request.form['name']
        student.usn = request.form['usn']
        student.department = request.form['department']

        student.attendance = float(request.form['attendance'])

        student.python = float(request.form['python'])
        student.dbms = float(request.form['dbms'])
        student.dsa = float(request.form['dsa'])
        student.maths = float(request.form['maths'])
        student.fcn = float(request.form['fcn'])

        db.session.commit()

        return redirect(url_for('teacher_dashboard'))

    return render_template(
        'edit_student.html',
        student=student
    )


# ==========================
# DELETE STUDENT
# ==========================
@app.route('/delete_student/<int:id>')
def delete_student(id):

    student = Student.query.get_or_404(id)

    db.session.delete(student)
    db.session.commit()

    return redirect(url_for('teacher_dashboard'))


# ==========================
# ATTENDANCE UPDATE
# ==========================
@app.route('/update_attendance/<int:id>', methods=['GET', 'POST'])
def update_attendance(id):

    student = Student.query.get_or_404(id)

    if request.method == 'POST':

        student.attendance = float(
            request.form['attendance']
        )

        db.session.commit()

        return redirect(url_for('teacher_dashboard'))

    return render_template(
        'attendance.html',
        student=student
    )


# ==========================
# ATTENDANCE PAGE
# ==========================
@app.route('/student_attendance')
def student_attendance():

    students = Student.query.all()

    return render_template(
        'student_attendance.html',
        students=students
    )


# ==========================
# ANALYTICS
# ==========================
@app.route('/analytics')
def analytics():

    students = Student.query.all()

    total_students = len(students)

    names = [s.name for s in students]

    marks = [s.average_marks() for s in students]

    attendance = [s.attendance for s in students]

    avg_marks = round(sum(marks) / len(marks), 2) if marks else 0
    avg_attendance = round(sum(attendance) / len(attendance), 2) if attendance else 0

    return render_template(
        'analytics.html',
        total_students=total_students,
        avg_marks=avg_marks,
        avg_attendance=avg_attendance,
        names=names,
        marks=marks,
        attendance=attendance
    )


# ==========================
# EXPORT EXCEL
# ==========================
@app.route('/export_excel')
def export_excel():

    students = Student.query.all()
    data = []

    for s in students:
        data.append({
            "ID": s.id,
            "Name": s.name,
            "USN": s.usn,
            "Department": s.department,
            "Attendance": s.attendance,
            "Average Marks": s.marks
        })

    df = pd.DataFrame(data)
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Students')
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name='student_report.xlsx',
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )


# ==========================
# TOPPER
# ==========================
@app.route('/topper')
def topper():

    students = Student.query.all()

    if not students:
        return "No Students Found"

    topper = max(
        students,
        key=lambda s: s.average_marks()
    )

    return render_template(
        'topper.html',
        topper=topper
    )


# ==========================
# RANKLIST
# ==========================
@app.route('/ranklist')
def ranklist():

    students = Student.query.all()

    students = sorted(
        students,
        key=lambda s: s.average_marks(),
        reverse=True
    )

    return render_template(
        'ranklist.html',
        students=students
    )


# ==========================
# EXPORT PDF
# ==========================
@app.route('/export_pdf')
def export_pdf():

    students = Student.query.order_by(Student.marks.desc()).all()
    buffer = io.BytesIO()

    pdf = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    pdf.setTitle('Student Performance Report')
    pdf.setFont('Helvetica-Bold', 18)
    pdf.drawString(40, height - 60, 'Student Performance Report')
    pdf.setFont('Helvetica', 11)
    pdf.drawString(40, height - 84, 'Generated by Student Performance Analyzer')

    line_y = height - 120
    pdf.setFont('Helvetica-Bold', 10)
    pdf.drawString(40, line_y, 'USN')
    pdf.drawString(120, line_y, 'Name')
    pdf.drawString(330, line_y, 'Attendance')
    pdf.drawString(430, line_y, 'Avg Marks')
    pdf.drawString(520, line_y, 'Result')
    pdf.setFont('Helvetica', 10)
    line_y -= 18

    for s in students:
        if line_y < 72:
            pdf.showPage()
            line_y = height - 60
            pdf.setFont('Helvetica-Bold', 10)
            pdf.drawString(40, line_y, 'USN')
            pdf.drawString(120, line_y, 'Name')
            pdf.drawString(330, line_y, 'Attendance')
            pdf.drawString(430, line_y, 'Avg Marks')
            pdf.drawString(520, line_y, 'Result')
            line_y -= 18
            pdf.setFont('Helvetica', 10)

        pdf.drawString(40, line_y, str(s.usn))
        pdf.drawString(120, line_y, s.name[:24])
        pdf.drawString(330, line_y, f"{s.attendance:.2f}%")
        pdf.drawString(430, line_y, f"{s.marks:.2f}")
        pdf.drawString(520, line_y, s.result())
        line_y -= 18

    pdf.save()
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name='student_report.pdf',
        mimetype='application/pdf'
    )


# ==========================
# RUN APP
# ==========================
if __name__ == "__main__":
    app.run(debug=True)